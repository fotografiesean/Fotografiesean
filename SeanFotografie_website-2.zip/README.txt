SeanFotografie website
======================
Open index.html in a browser to preview the website.

The contact form opens the visitor's email app with a pre-filled message to:
fotografiesean@gmail.com

Instagram: https://www.instagram.com/seanfotografie/
Phone: 06 15511850
